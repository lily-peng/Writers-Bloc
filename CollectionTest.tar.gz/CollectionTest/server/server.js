var Messages = new Meteor.Collection('messages');
var Channels = new Meteor.Collection('channels');

Meteor.publish('channels', function() {
  return Channels.find({});
});

Meteor.publish('messages', function(channel) {
  return Messages.find({channel: channel});
});

Meteor.methods({
  insertMessage: function(channel, message) {
    if (Channels.find({channel: channel}).fetch().length == 0) {
      Channels.insert({channel: channel});
    }
    Messages.insert({channel: channel, message: message});
  }
});

