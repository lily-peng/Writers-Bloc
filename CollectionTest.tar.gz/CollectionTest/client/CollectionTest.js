var Messages = new Meteor.Collection('messages');
var Channels = new Meteor.Collection('channels');

Meteor.subscribe('channels');

Deps.autorun(function () {
  var channel = Session.get('channel');
  Meteor.subscribe('messages', channel);
});

Template.input.events = {
  'click #submit': function(event) {
    var channel = document.getElementById('channelInput');
    var message = document.getElementById('messageInput');
    
    if (channel.value == '') {
      alert('Please enter a channel.');
      return;
    } else if (message.value == '') {
      alert('Please enter a message.');
      return;
    } else {
      Meteor.call('insertMessage', channel.value, message.value);
      message.value = '';
    }
  }
}

Template.channels.channels = function() {
  return Channels.find({});
}

Template.channels.title = function() {
  var channelsLength = Channels.find({}).fetch().length;
  if (channelsLength == 0) {
    return '';
  } else {
    return '<h3>Current channels:</h3>';
  }
}

Template.channels.events = {
  'change': function(event) {
    var currentChannel = '';
    var radioButtons = document.getElementsByName('currentChannel');
    for (var i = 0; i < radioButtons.length; i++) {
      var currentRadio = radioButtons[i];
      if (currentRadio.checked) {
        currentChannel = currentRadio.value;
      }
    }
    Session.set('channel', currentChannel);
  }
}

Template.messages.messages = function() {
  return Messages.find({});
}

Template.messages.title = function() {
  var channel = Session.get('channel');
  if (channel == undefined) {
    return '';
  } else {
    return 'Current messages in channel ' + channel + ':';
  }
}

